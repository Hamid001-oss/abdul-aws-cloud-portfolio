# AWS Interview Talking Points — Abdul Hamid Bakarr-Kanu

## Tell me about yourself

I am an AWS Certified Cloud Practitioner with hands-on project experience in AWS infrastructure, Terraform, Docker and CI/CD. I have built portfolio environments covering networking, EC2, load balancing, Auto Scaling, serverless services, containers, monitoring and cloud security. I am targeting a Cloud Support, Cloud Operations or Junior DevOps role where I can combine troubleshooting with cloud infrastructure skills.

## Tell me about an AWS project

One of my main projects is a highly available web architecture. Instead of using a single EC2 instance, I designed the application tier across multiple Availability Zones behind an Application Load Balancer and incorporated Auto Scaling. The purpose was to improve availability and make the environment more resilient to instance failures.

## Why Terraform?

Terraform lets me define infrastructure as code, review changes, reuse configuration and keep infrastructure consistent. It is especially useful when environments need to be recreated or managed through source control.

## Public vs private subnet

A public subnet has a route to an Internet Gateway. A private subnet does not expose resources directly through an Internet Gateway. I would normally keep databases and internal application resources private and expose only the components that need public access.

## Security group

A security group acts as a stateful virtual firewall around AWS resources. I use it to allow only necessary traffic and prefer referencing another security group between application tiers rather than opening broad CIDR ranges.

## CloudWatch vs CloudTrail

CloudWatch focuses on monitoring, metrics, logs and alarms. CloudTrail records AWS API activity and helps with auditing and investigating who or what made changes to an AWS environment.

## Troubleshooting mindset

I first identify the symptom and affected layer. For an unreachable application, I would check DNS, load-balancer health, security groups, route tables, instance status, application logs and CloudWatch data rather than changing multiple things at once.
