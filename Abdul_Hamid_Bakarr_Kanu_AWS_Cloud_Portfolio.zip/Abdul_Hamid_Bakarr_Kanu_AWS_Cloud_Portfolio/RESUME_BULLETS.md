# Resume-Ready AWS Project Bullets

## Cloud Projects

- Designed a highly available AWS web architecture using VPC, EC2, Application Load Balancer, Auto Scaling, multi-AZ networking and security groups.
- Developed reusable Terraform configuration for AWS infrastructure, including VPC resources, subnet segmentation, variables and security controls.
- Designed a serverless AWS application using S3, CloudFront, API Gateway, Lambda and DynamoDB.
- Built a container deployment project using Docker, Amazon ECR and Amazon ECS/Fargate concepts.
- Created a GitHub Actions CI workflow to automatically format-check, initialize and validate Terraform infrastructure code.
- Designed AWS monitoring and audit workflows using CloudWatch, CloudTrail and SNS, with a focus on troubleshooting and least-privilege IAM.
- Documented cloud architecture decisions, security considerations, troubleshooting approaches and deployment workflows in GitHub-style technical documentation.

## Suggested Resume Project Heading

**AWS Cloud & DevOps Projects — Personal Technical Portfolio**

AWS | Terraform | Docker | GitHub Actions | Linux | VPC | EC2 | S3 | RDS | Lambda | ECS | CloudWatch
