# AWS Monitoring, Logging and Security


## Project Summary

Designed an AWS operations project around auditability, monitoring and alerting.

## AWS Services

- CloudWatch
- CloudTrail
- SNS
- IAM
- Security Groups

## What I Implemented

- Documented CloudWatch metrics and alarm use cases.
- Designed SNS alert notifications for operational events.
- Used CloudTrail concepts to track AWS API activity.
- Documented IAM least-privilege practices.
- Reviewed security-group access patterns.
- Created an incident-troubleshooting checklist.

## Skills Demonstrated

Cloud operations, troubleshooting, AWS logging, monitoring, audit trails, alerting and access control.

## Interview Explanation

> My goal was to show the operational side of AWS. Building resources is only part of cloud engineering; you also need logging, visibility, alerts and a way to investigate changes when something goes wrong.
