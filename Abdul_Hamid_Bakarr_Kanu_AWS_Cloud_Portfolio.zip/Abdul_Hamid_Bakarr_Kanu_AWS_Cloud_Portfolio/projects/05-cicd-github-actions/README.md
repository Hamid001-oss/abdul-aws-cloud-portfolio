# CI/CD with GitHub Actions and AWS


## Project Summary

Created a CI/CD workflow example that validates Terraform and demonstrates how infrastructure changes can be checked automatically from a GitHub repository.

## Tools

- GitHub Actions
- Terraform
- Git
- AWS
- YAML

## Pipeline

1. Developer pushes code.
2. GitHub Actions checks out the repository.
3. Terraform is initialized.
4. Terraform formatting is checked.
5. Terraform configuration is validated.
6. A plan can be generated before deployment approval.

## Skills Demonstrated

CI/CD, YAML, Terraform automation, Git workflows and infrastructure validation.

## Interview Explanation

> I used GitHub Actions to automate repeatable checks instead of relying only on manual validation. This demonstrates the CI side of a DevOps workflow and provides a foundation for controlled deployments.
