# Highly Available AWS Web Architecture


## Project Summary

Designed a highly available AWS web architecture intended to remain available if a single compute instance or Availability Zone experiences a failure.

## Architecture

Internet users connect through an Application Load Balancer. Traffic is distributed across EC2 instances deployed in multiple Availability Zones. Auto Scaling maintains capacity and replaces unhealthy instances. Security groups restrict access by role.

## AWS Services

- Amazon VPC
- EC2
- Application Load Balancer
- Auto Scaling
- Internet Gateway
- Route Tables
- Security Groups
- CloudWatch

## What I Implemented

- Created a custom VPC.
- Separated resources across multiple subnets and Availability Zones.
- Configured web-tier EC2 instances.
- Placed an Application Load Balancer in front of the instances.
- Used health checks and Auto Scaling for resilience.
- Restricted inbound traffic with security groups.
- Used CloudWatch concepts for operational visibility.

## Skills Demonstrated

High availability, VPC networking, EC2 troubleshooting, load balancing, Auto Scaling, security groups, operational monitoring and AWS architecture.

## Interview Explanation

> I built this project to demonstrate how I would avoid relying on a single EC2 instance. I used multiple Availability Zones, a load balancer and Auto Scaling so the application tier could tolerate instance failure and automatically maintain capacity.
