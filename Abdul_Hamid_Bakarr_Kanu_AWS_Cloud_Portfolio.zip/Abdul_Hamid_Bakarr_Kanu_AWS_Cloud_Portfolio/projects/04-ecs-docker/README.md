# Docker and Amazon ECS Deployment


## Project Summary

Built a container-focused AWS project demonstrating how an application image can be packaged with Docker, stored in Amazon ECR and run using Amazon ECS on Fargate.

## Tools and AWS Services

- Docker
- Amazon ECR
- Amazon ECS
- AWS Fargate
- IAM
- CloudWatch Logs

## What I Implemented

- Containerized a simple web application.
- Defined a Docker image build.
- Designed an ECR image repository workflow.
- Created an ECS/Fargate task definition example.
- Documented IAM and CloudWatch logging requirements.
- Documented the flow from source code to running container.

## Skills Demonstrated

Docker, container registries, ECS, Fargate, deployment architecture and troubleshooting.

## Interview Explanation

> This project shows that I understand the container lifecycle: package an application into an image, store that image in a registry, then deploy it through a managed orchestration service such as ECS.
