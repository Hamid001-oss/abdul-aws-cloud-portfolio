# Secure Three-Tier AWS Environment with Terraform


## Project Summary

Created Infrastructure as Code for a segmented AWS environment using Terraform. The design separates public-facing resources from internal application and database components.

## Architecture

The environment uses a custom VPC with public and private subnet tiers. Security rules are designed so database access originates only from the application tier rather than the public internet.

## AWS Services / Tools

- Terraform
- Amazon VPC
- EC2
- RDS
- IAM
- Security Groups
- AWS CLI

## What I Implemented

- Defined AWS infrastructure using Terraform.
- Created a reusable VPC configuration.
- Built public and private subnet tiers.
- Added security group relationships between tiers.
- Designed an RDS database layer without public exposure.
- Used variables and outputs to make configuration easier to reuse.

## Skills Demonstrated

Terraform, Infrastructure as Code, network segmentation, RDS security, reusable configuration and cloud automation.

## Interview Explanation

> This project helped me move from manually creating AWS resources to defining infrastructure as code. I focused on repeatability and security, especially keeping the database tier private and controlling traffic between application layers.
