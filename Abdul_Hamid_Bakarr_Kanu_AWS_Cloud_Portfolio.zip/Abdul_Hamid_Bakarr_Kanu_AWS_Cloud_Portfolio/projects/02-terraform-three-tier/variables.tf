variable "aws_region" {
  description = "AWS region used for the portfolio environment."
  type        = string
  default     = "us-west-2"
}
