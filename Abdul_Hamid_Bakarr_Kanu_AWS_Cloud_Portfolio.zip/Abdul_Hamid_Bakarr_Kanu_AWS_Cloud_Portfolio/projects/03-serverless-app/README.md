# Serverless AWS Application


## Project Summary

Designed a serverless web application architecture that minimizes server management while using managed AWS services.

## Architecture

Static content is served from Amazon S3 through CloudFront. API requests are handled through API Gateway and AWS Lambda, with DynamoDB providing managed NoSQL data storage.

## AWS Services

- Amazon S3
- CloudFront
- API Gateway
- AWS Lambda
- DynamoDB
- IAM
- CloudWatch

## What I Implemented

- Designed static frontend hosting with S3.
- Added CloudFront as the content delivery layer.
- Created API architecture using API Gateway and Lambda.
- Used DynamoDB as the application data store.
- Applied IAM permissions to service interactions.
- Included CloudWatch logging concepts for troubleshooting.

## Skills Demonstrated

Serverless computing, APIs, managed databases, IAM, AWS integration and cost-aware cloud design.

## Interview Explanation

> I chose serverless services because they reduce infrastructure management. The project demonstrates how a frontend can call an API without maintaining traditional application servers, while Lambda and DynamoDB scale with demand.
