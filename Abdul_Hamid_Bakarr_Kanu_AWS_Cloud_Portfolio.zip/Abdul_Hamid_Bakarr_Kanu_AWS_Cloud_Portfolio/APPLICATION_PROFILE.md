# Application Profile

**Name:** Abdul Hamid Bakarr-Kanu  
**Professional Positioning:** AWS Cloud / Cloud Operations / Cloud Support / Junior DevOps  
**Certification:** AWS Certified Cloud Practitioner  
**Portfolio Type:** Personal hands-on technical projects

## Job Titles to Target

Cloud Support Associate  
Cloud Support Engineer  
Cloud Operations Engineer  
Junior Cloud Engineer  
Junior DevOps Engineer  
Infrastructure Support Engineer  
Technical Support Engineer — Cloud

## Skills Keywords for ATS

AWS, Amazon Web Services, EC2, VPC, S3, IAM, RDS, Route 53, CloudFront, Lambda, DynamoDB, ECS, ECR, Docker, Terraform, GitHub Actions, CI/CD, Linux, CloudWatch, CloudTrail, SNS, Infrastructure as Code, networking, troubleshooting, security groups, Auto Scaling, Application Load Balancer.
